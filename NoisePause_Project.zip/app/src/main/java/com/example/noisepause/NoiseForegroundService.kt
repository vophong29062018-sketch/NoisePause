package com.example.noisepause

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.session.MediaSessionManager
import android.os.IBinder
import androidx.core.app.NotificationCompat

class NoiseForegroundService : Service() {
    private lateinit var detector: NoiseDetector
    private var pausedByUs = false
    private var lastLoudTime = 0L
    private var lastQuietTime = 0L

    override fun onCreate() {
        super.onCreate()
        detector = NoiseDetector()
        startForeground(1, buildNotification())

        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        val threshold = prefs.getInt("threshold", 60)
        val minDuration = prefs.getInt("minDurationMs", 500)
        val resumeAfter = prefs.getInt("resumeAfterMs", 1500)

        val mediaManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager

        detector.start { db ->
            val now = System.currentTimeMillis()
            if (db >= threshold) {
                lastLoudTime = now
                lastQuietTime = 0
                if (!pausedByUs && (now - lastLoudTime) >= minDuration) {
                    sendMediaCommand(mediaManager, play = false)
                    pausedByUs = true
                }
            } else {
                if (pausedByUs) {
                    if (lastQuietTime == 0L) lastQuietTime = now
                    if (now - lastQuietTime >= resumeAfter) {
                        sendMediaCommand(mediaManager, play = true)
                        pausedByUs = false
                    }
                }
            }
        }
    }

    private fun sendMediaCommand(mediaManager: MediaSessionManager, play: Boolean) {
        try {
            val controllers = mediaManager.getActiveSessions(null)
            if (controllers.isNotEmpty()) {
                val controller = controllers[0]
                if (play) controller.transportControls.play() else controller.transportControls.pause()
            }
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "noisepause_channel")
            .setContentTitle("NoisePause running")
            .setContentText("Giám sát âm thanh để pause/play media")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .build()
    }

    override fun onDestroy() {
        detector.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
