package com.example.noisepause

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.widget.Button
import android.widget.TextView
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {
    private val requestRecord = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)
        val btnNotifAccess = findViewById<Button>(R.id.btnNotifAccess)
        val slider = findViewById<Slider>(R.id.sliderThreshold)
        val tvThreshold = findViewById<TextView>(R.id.tvThreshold)

        slider.addOnChangeListener { _, value, _ ->
            tvThreshold.text = "Ngưỡng: ${value.toInt()} dB"
            getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("threshold", value.toInt()).apply()
        }

        btnStart.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestRecord.launch(Manifest.permission.RECORD_AUDIO)
            }
            startService(Intent(this, NoiseForegroundService::class.java))
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, NoiseForegroundService::class.java))
        }

        btnNotifAccess.setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
    }
}
