package com.example.noisepause

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.log10
import kotlin.math.sqrt

class NoiseDetector {
    private val sampleRate = 44100
    private val channel = AudioFormat.CHANNEL_IN_MONO
    private val encoding = AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channel, encoding)

    private var audioRecord: AudioRecord? = null
    private var running = false

    fun start(onRmsDb: (Double) -> Unit) {
        if (running) return
        audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channel, encoding, bufferSize)
        audioRecord?.startRecording()
        running = true

        Thread {
            val buffer = ShortArray(bufferSize)
            while (running) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (read > 0) {
                    var sumSquares = 0.0
                    for (i in 0 until read) {
                        val v = buffer[i].toDouble() / Short.MAX_VALUE
                        sumSquares += v * v
                    }
                    val rms = sqrt(sumSquares / read)
                    val db = if (rms > 0) 20 * log10(rms) + 120 else 0.0
                    onRmsDb(db)
                }
                Thread.sleep(150)
            }
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        }.start()
    }

    fun stop() {
        running = false
    }
}
